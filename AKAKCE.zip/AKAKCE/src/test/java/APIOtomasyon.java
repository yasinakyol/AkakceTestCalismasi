import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import static org.hamcrest.Matchers.*;

public class APIOtomasyon {

    private static final String BASE_URL = "https://jsonplaceholder.typicode.com/posts";

    @Test
    public void statuKoduTesti() {
        RestAssured.get(BASE_URL)
                .then()
                .statusCode(200); // Status Code'un 200 olduğunu kontrol eder
        System.out.println("Status Code testi başarılıdır."); // Konsola başarılı mesajı yazdırır

    }

    @Test
    public void jsonYapisiDogrulama() {
        RestAssured.get(BASE_URL)
                .then()
                .assertThat()
                .statusCode(200)  // Status Code'un 200 olduğunu kontrol eder
                .body("$", is(not(empty())))  // Dönen response'un boş olup olmadığını kontrol eder
                .body("$", hasItem(allOf(
                        hasKey("userId"),
                        hasKey("id"),
                        hasKey("title"),
                        hasKey("body")
                )))  // Dönen response'da userId, id, title ve body alanlara sahip olduğunu kontrol eder
                .body("$", hasSize(greaterThanOrEqualTo(1)));  // Nesnenin en az 1 öğe içerdiğini kontrol eder
        System.out.println("JSON yapısı doğrulama başarılıdır."); // Konsola başarılı mesajı yazdırır
    }

    @Test
    public void belirliBirDegerinDogrulanmasi() {
        RestAssured.get(BASE_URL)
                .then()
                .body("find { it.id == 1 }.title", equalTo("sunt aut facere repellat provident occaecati excepturi optio reprehenderit")); // id değeri 1 olan nesneyi bulup ve bu nesnenin 'title' alanının belirtilen değere eşit olduğunu kontrol eder.
        System.out.println("Belirli bir değerin doğrulanması durumu başarılıdır."); // Konsola başarılı mesajı yazdırır
    }

    @Test
    public void listeUzunlukKontrolu() {
        RestAssured.get(BASE_URL)
                .then()
                .body("size()", greaterThanOrEqualTo(10)); // Liste uzunluğunun en az 10 olduğunu kontrol eder
        System.out.println("Liste uzunluğu kontrolü başarılıdır."); // Konsola başarılı mesajı yazdırır
    }

    @Test
    public void dinamikVeriKontrolleri() {
        RestAssured.get(BASE_URL)
                .then()
                .body("id", not(empty())) // id değerinin boş olmamaması durumunu kontrol eder
                .body("id", everyItem(greaterThan(0))); //  id değerinin 0'dan büyük olduğu durumu kontrol eder
        System.out.println("Dinamik veri kontrolleri başarılıdır."); // Konsola başarılı mesajı yazdırır
    }
}