package tests;

        import org.junit.jupiter.api.Test;
        import org.openqa.selenium.By;
        import org.openqa.selenium.JavascriptExecutor;
        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.WebElement;
        import org.openqa.selenium.chrome.ChromeDriver;

public class AkakceUItest {

    @Test
    public void akakceUITest(){
        WebDriver driver = new ChromeDriver(); //Chrome'u aç
        driver.manage().window().maximize(); //Sayfayı büyüt
        driver.get("https://akakce.com/"); //Akakçe web sayfasını aç
        WebElement aramaCubugu = driver.findElement(By.name("q")); //Arama çubuğunu tanımla
        aramaCubugu.sendKeys("PlayStation 5"); //Arama çubuğuna PlayStation 5 yaz
        aramaCubugu.submit(); //Ara
        WebElement uruneGitButon = driver.findElement(By.cssSelector(".pw_v8[href='https://www.akakce.com/ps5/en-ucuz-sony-playstation-5-slim-digital-edition-1-tb-oyun-konsolu-2-dualsense-ithalatci-garantili-fiyati,650331522.html'] .bt_v8 > b")); //Arama sonuçlarından seç
        uruneGitButon.click(); //Ürüne git butonuna tıkla
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0, 500)"); //Sayfada scroll down yap
        WebElement takipEtButon = driver.findElement(By.xpath("//span[.='Takip Et500+ takip']")); //Takip et butonunu tanımla
        takipEtButon.click(); //Takip et butonuna tıkla
        driver.close(); //Chrome'u kapat
    }

}